package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class EthnicgroupsFragment extends Fragment implements AdapterView.OnItemClickListener {
    ListView listView;
    ArrayAdapter<String> arrayAdapter;

    //String[] ethnicgroupsFragment = {"ETHNIC GROUPS","Ewe 45.8%)","Adangbe (28.1%)","Akan (11.6%)","","RELIGION","Christianity (89%)", "Islamic (3.7%)", "Traditionalist (2.4%) "};

    public EthnicgroupsFragment(){
        //constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.ethnicsgroups,container,false);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ListView listView = view.findViewById(R.id.listView);


        //String history_string = getActivity().getResources().getString(R.string.history_string);
        String history_string = getResources().getString(R.string.history_string);


        //setting ArrayAdapter on listView
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 1) {
                    Toast.makeText(getActivity(), "Ewes are 45.8% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "Adangbes are 28..1% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "Akans are 11.6% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 6) {
                    Toast.makeText(getActivity(), "Christianity is the major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 7) {
                    Toast.makeText(getActivity(), "Islam is the second major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 8) {
                    Toast.makeText(getActivity(), "The Traditional worshippers are the minority", Toast.LENGTH_SHORT).show();
                }

            }
        });

        }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
        }
